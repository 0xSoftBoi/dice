# YungBet.GG

- YungBet is a profit-sharing gaming platform on the EOS.IO blockchain. 

- Thanks to the ecosystem of the blockchain, we are able to build a brand-new gambling platform, offering a safe, trustless and borderless gambling system. 

- All our games are provably fair and maintained by the blockchain. 

- Our DICE2.0 token allows holders to receive dividends from game profits on our platform. Cross-platform allows our users to play anytime and anywhere. 

## About Our Team

- The Dice2.0 team has extensive experience as a game developer on Android, IOS and Web. 

- There are a lot of DApps on the blockchain, but we believe our experience developing, operating and marketing games will allow us to outperform our competition. 

## Smart Contract API

- Review `CONTRACT.md`

## React Web App

- TBD/ Estimate 11/14/2018
